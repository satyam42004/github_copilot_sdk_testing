import asyncio

from copilot import CopilotClient
from copilot.session import PermissionHandler

from tools import list_files, read_file, search_code


async def main():
    print("Starting Copilot SDK...")

    client = CopilotClient()

    await client.start()

    print("Copilot started.")

    session = await client.create_session(
        on_permission_request=PermissionHandler.approve_all,
        model="auto",
        tools=[
            list_files,
            read_file,
            search_code,
        ],
    )

    print("Repository tools configured.")

    response = await session.send_and_wait(
        """
You are a GitHub Repository Assistant.

You have access to these repository tools:

1. list_files
   - Lists files in the configured repository.

2. read_file
   - Reads a specific file from the configured repository.

3. search_code
   - Searches for code, symbols, classes, functions, or text.

The repository path is already configured inside the tools.
Do NOT ask the user for a repository path.

For this task:

1. Use list_files to understand the repository structure.
2. Find requirements.txt if it exists.
3. Read requirements.txt.
4. Inspect relevant source files.
5. Explain what the project possibly does.
6. Identify the technologies used.
7. Explain the major components.
8. Mention important observations from the code.

Your answer MUST be based on information returned by the repository tools.

Do not invent repository information.
If a required file cannot be found, explicitly say so.
"""
    )

    print("\nAssistant:")
    print(response.data.content)

    await client.stop()

    print("\nCopilot stopped.")


if __name__ == "__main__":
    asyncio.run(main())
